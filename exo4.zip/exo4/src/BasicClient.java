import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.net.Socket;
import java.util.Scanner;

public class BasicClient {
    public static void main(String[] args) {
        try {
            Socket clientSocket = new Socket("localhost", 5000);
            System.out.println("Connecté au serveur pour calcul. Tapez 'bye' pour quitter.");

            OutputStream os = clientSocket.getOutputStream();
            PrintWriter pw = new PrintWriter(os, true);

            InputStream is = clientSocket.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader input = new BufferedReader(isr);

            Scanner sc = new Scanner(System.in);
            String operation;

            while (true) {
                System.out.print("Entrez une opération (ex. 5 + 3) : ");
                operation = sc.nextLine();

                pw.println("CALCUL:" + operation);
                if (operation.equalsIgnoreCase("bye")) {
                    break;
                }

                String response = input.readLine();
                System.out.println("Réponse du serveur : " + response);
            }

            clientSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
